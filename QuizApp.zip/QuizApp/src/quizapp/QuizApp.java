package quizapp;
public class QuizApp {

    public static void main(String[] args) throws InterruptedException {
   SplashScreen s=new SplashScreen();   
    for(int i=0;i<=100;i++)
          {
       Thread.sleep(45);
       s.setVisible(true);
       s.setBounds(50,70,720,590);
       s.Label.setText("loading "+i+"%");
       s.Bar.setValue(i);
       if(i==100)
       {
         s.dispose();
              Cover l=new Cover();
       l.setVisible(true);
       l.setBounds(50,50,720,590);
       }
           
       
   }
  /*  Ques1 x=new Ques1();   
    for(int i=0;i<=100;i++)
          {
       Thread.sleep(75);
       //x.setVisible(true);
       //s.setBounds(50,70,720,590);
       x.jLabel4.setText("loading "+i+"%");
      // x.Bar.setValue(i);
       if(i==200)
       {
         x.dispose();
              Final l=new Final();
       x.setVisible(true);
       x.setBounds(50,50,720,590);
       }
           */
       
   }
    }
    

