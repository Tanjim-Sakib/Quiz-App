package quizapp;

import com.opencsv.CSVWriter;
import java.io.FileWriter;
import java.util.List;
import javax.swing.JOptionPane;


public class Ques1 extends javax.swing.JFrame {
    
    
  
 String m;
    String n;
     String o;
      String p;
       String q;
       
       public void  SetQuestion(String question,String a,String b,String c ,String d){
           jLabel1.setText(m);
           jRadioButton1.setText(a);
           jRadioButton1.setText(b);
           jRadioButton1.setText(c);
           jRadioButton1.setText(d);

       }
       
    
    public static java.util.ArrayList<String[]> all_questions = new Authentication().all_questions;
 public void Ques11()
  { 
  
      
      
      System.out.println(m);
      System.out.println(n);
      System.out.println(o);
      System.out.println(p);
      System.out.println(q);
      
     jLabel1.setText(all_questions.get(0)[0]);
      
     jRadioButton1.setText(all_questions.get(0)[1]);
      
    jRadioButton2.setText(all_questions.get(0)[2]);
      
   jRadioButton3.setText(all_questions.get(0)[3]);
      
   jRadioButton4.setText(all_questions.get(0)[4]);
   if(jRadioButton1.isSelected()){
           f=1;
           System.out.println(" f " + f);
           
       }
    if(jRadioButton2.isSelected()){
           f=2;
           System.out.println(" f " + f);
       }
     if(jRadioButton3.isSelected()){
           f=3;
           System.out.println("jbutton 3 " + f);
       }
      if(jRadioButton4.isSelected()){
           f=4;
           System.out.println("jbutton 4 "+ f);
           
       }
        if(f==Integer.valueOf(all_questions.get(0)[5])){
       count=count+5;
       System.out.println("ji");
   }
   
  }
    
    
    public static int index=1;
    public Ques1() {
        initComponents();
        
        /*  for(int i=0;i<=200;i++)
          {
       Thread.sleep(75);
      
       jLabel4.setText(i+"s");
       //s.Bar.setValue(i);
       if(i==100)
       {
         dispose();
              Final l=new Final();
       l.setVisible(true);
       l.setBounds(50,50,720,590);
       }
           */
        
        
        Ques11();
        System.out.println("1");
        
         // setLocationRelativeTo(this);
 
//int n=0;
// n++;
 //if(n==1){
 //Authentication obj =  new Authentication();
 // obj.ques();}
//Ques1 l=new Ques1();
 //  l.Ques11(a,b,c,d,e); 
 
    }
    public Ques1(String ques,String a,String b,String c,String d){
         initComponents();
         m=ques;
          n=a;
           o=b;
            p=c;
             q=d;
         Ques11();
    }

  /* void Ques11(String ques,String a,String b,String c,String d)
  { 
   String m=ques;
    String n=a;
     String o=b;
      String p=c;
       String q=d;
      System.out.println(m);
      System.out.println(n);
      System.out.println(o);
      System.out.println(p);
      System.out.println(q);
      
     jLabel1.setText(m);
      
     jRadioButton1.setText(n);
      
    jRadioButton2.setText(o);
      
   jRadioButton3.setText(p);
      
   jRadioButton4.setText(q);
  }
    
    */
    Authentication auth = new Authentication();
    

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        panel1 = new java.awt.Panel();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jRadioButton4 = new javax.swing.JRadioButton();
        jRadioButton3 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jRadioButton1 = new javax.swing.JRadioButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        panel1.setLayout(null);

        jButton2.setBackground(java.awt.Color.darkGray);
        jButton2.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Submit");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        panel1.add(jButton2);
        jButton2.setBounds(50, 490, 110, 40);

        jButton1.setBackground(java.awt.Color.darkGray);
        jButton1.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Next");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        panel1.add(jButton1);
        jButton1.setBounds(540, 490, 110, 40);

        jLabel1.setBackground(java.awt.Color.darkGray);
        jLabel1.setFont(new java.awt.Font("RomanT", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 0), 2));
        panel1.add(jLabel1);
        jLabel1.setBounds(10, 120, 690, 110);

        jRadioButton4.setBackground(java.awt.Color.darkGray);
        buttonGroup1.add(jRadioButton4);
        jRadioButton4.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jRadioButton4.setForeground(new java.awt.Color(255, 255, 255));
        jRadioButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton4ActionPerformed(evt);
            }
        });
        panel1.add(jRadioButton4);
        jRadioButton4.setBounds(380, 390, 230, 40);

        jRadioButton3.setBackground(java.awt.Color.darkGray);
        buttonGroup1.add(jRadioButton3);
        jRadioButton3.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jRadioButton3.setForeground(new java.awt.Color(255, 255, 255));
        jRadioButton3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 51), 9));
        panel1.add(jRadioButton3);
        jRadioButton3.setBounds(80, 390, 240, 40);

        jRadioButton2.setBackground(java.awt.Color.darkGray);
        buttonGroup1.add(jRadioButton2);
        jRadioButton2.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jRadioButton2.setForeground(new java.awt.Color(255, 255, 255));
        jRadioButton2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 255, 153), 3, true));
        panel1.add(jRadioButton2);
        jRadioButton2.setBounds(380, 300, 230, 40);

        jRadioButton1.setBackground(java.awt.Color.darkGray);
        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setFont(new java.awt.Font("Arial", 3, 14)); // NOI18N
        jRadioButton1.setForeground(new java.awt.Color(255, 255, 255));
        jRadioButton1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 0), 2, true));
        jRadioButton1.setBorderPainted(isAlwaysOnTop());
        jRadioButton1.setMargin(new java.awt.Insets(4, 4, 2, 2));
        jRadioButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jRadioButton1MouseClicked(evt);
            }
        });
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });
        panel1.add(jRadioButton1);
        jRadioButton1.setBounds(80, 300, 240, 40);

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Background.jpg"))); // NOI18N
        jLabel2.setText("jLabel2");
        panel1.add(jLabel2);
        jLabel2.setBounds(0, 0, 720, 560);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panel1, javax.swing.GroupLayout.PREFERRED_SIZE, 563, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 55, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jRadioButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton4ActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
         //jRadioButton1.setText("ttttt");
    }//GEN-LAST:event_jRadioButton1ActionPerformed
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
          if(index>9){
              JOptionPane.showMessageDialog(null, "Press submit button to submit all your answers  ","Question Completed" , JOptionPane.PLAIN_MESSAGE);
        }
          else{
              
       
        jLabel1.setText(all_questions.get(index)[0]);
      
     jRadioButton1.setText(all_questions.get(index)[1]);
      
    jRadioButton2.setText(all_questions.get(index)[2]);
      
   jRadioButton3.setText(all_questions.get(index)[3]);
      
   jRadioButton4.setText(all_questions.get(index)[4]);
   if(jRadioButton1.isSelected()){
           f=1;
           
       }
    if(jRadioButton2.isSelected()){
           f=2;
           
       }
     if(jRadioButton3.isSelected()){
           f=3;
           System.out.println("jbutton 3 ");
       }
      if(jRadioButton4.isSelected()){
           f=4;
           System.out.println("jbutton 4 ");
           
       }
              System.out.println(" etai" + Integer.valueOf(all_questions.get(index)[5]));
   if(f==Integer.valueOf(all_questions.get(index-1)[5])){
       count++;
       System.out.println("Ekhane ???");
   }
              System.out.println("count " + count);
   index++;
          }
        System.out.println(f);
    }//GEN-LAST:event_jButton1ActionPerformed
    public static int count  = 0;
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       
         if(f==Integer.valueOf(all_questions.get(index-1)[5])){
       count++;
       System.out.println("Ekhane ???");
   }
         if(jRadioButton1.isSelected()){
           f=1;
           
       }
    if(jRadioButton2.isSelected()){
           f=2;
           
       }
     if(jRadioButton3.isSelected()){
           f=3;
           System.out.println("jbutton 3 ");
       }
      if(jRadioButton4.isSelected()){
           f=4;
           System.out.println("jbutton 4 ");
           
       }
      if(f==Integer.valueOf(all_questions.get(index-1)[5])){
       count++;
          System.out.println(count);
   }
    /*  try{
          CSVWriter writer = new CSVWriter(new FileWriter("result.csv",true));
          System.out.println(" username " + username);
      String [] record ={"yo", String.valueOf(count)};
       List<String[]> records = null;
      records.add(record);
      writer.writeAll(records);
      writer.flush();
      writer.close();
      }catch(Exception bibh){
          bibh.printStackTrace();
      }
        */
 //   Final x=new Final();
        // x.count(count);
        dispose();
        Final l=new Final();
       l.setVisible(true);
        l.count(count);
       l.setBounds(50,50,720,590);
    }//GEN-LAST:event_jButton2ActionPerformed
    public static int f = -1;
    private void jRadioButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jRadioButton1MouseClicked
       
    }//GEN-LAST:event_jRadioButton1MouseClicked
    public static String username;  
    public void getName(String name){
        this.username = name;
    }
  
  Ques1(String name){
          initComponents();
          username=name;
        Ques11();
  }
    /*public void time() throws InterruptedException{
        
    Ques1 p=new Ques1();
         for(int i=0;i<=200;i++)
          {
       Thread.sleep(75);
      
       p.jLabel4.setText(i+"s");
       //s.Bar.setValue(i);
       if(i==100)
       {
        p.dispose();
              Final l=new Final();
       l.setVisible(true);
       l.setBounds(50,50,720,590);
       }
    }
      */
  
    
    public static void main(String args[]) {

        
        System.out.println("q");
             Authentication obj =  new Authentication();
      obj.ques();
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ques1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ques1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ques1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ques1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ques1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    private java.awt.Panel panel1;
    // End of variables declaration//GEN-END:variables


   
   
}
