                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quizapp;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Dell
 */
public class Authentication {
    
  
    public static ArrayList<String[]> all_questions= new ArrayList<>();
    public int Admin_login (String username,String password){
        
        boolean bibh=false;
        try{
            FileReader filereader = new FileReader("Admin.csv");
            CSVReader reader  = new CSVReaderBuilder(filereader).withSkipLines(0).build();
            List<String[]>Students = reader.readAll();
            for(String[] student : Students){
                
                if(student[0].equals(username) && student[1].equals(password)){
                    bibh = true;
                    break;
                } 
            }                                                                                                                                       
        }catch(Exception e){
                  e.printStackTrace();
        }
        if(bibh==true) return 1;                                                                                                                                                                                                                                                      
        else return 0;        
    }
     public int Student_login (String name,String id,String mail){
        boolean bibh=false;
        try{
            FileReader filereader = new FileReader("Student.csv");
            CSVReader reader  = new CSVReaderBuilder(filereader).withSkipLines(0).build();
            List<String[]>Students = reader.readAll();
            for(String[] student : Students){
                 
                if(student[0].equals(name) && student[1].equals(id) && student[2].equals(mail)){
                    bibh = true;
                    break;
             }                                                           
            }                                          
        }catch(Exception e){
            e.printStackTrace();
        }
        if(bibh==true) return 1;
        else return 0;        
    }
        public void ques(){
            Admin y=new Admin();
            int z=y.yo();
            System.out.println(z+"keno");
            String ques=new String();
             String a=new String();
              String b=new String();
               String c=new String();
                String d=new String();
           // System.out.println("3");
      int x=0;
        try{
        //    System.out.println(n);
             System.out.println(w+"aaaaaaaaaaaaaa");  
             if(w==4){
            FileReader filereader = new FileReader("ques.csv");
            CSVReader reader  = new CSVReaderBuilder(filereader).withSkipLines(0).build();
            List<String[]>Students = reader.readAll();
            for(String[] student : Students){
                ques=student[0];
                a=student[1];
                //  System.out.println(ques);
                   b=student[2];
                    c=student[3];
                     d=student[4];
                    all_questions.add(student);
          
                 
                 
            }  }
            else if(w==3){
            FileReader filereader = new FileReader("prog.csv");
            CSVReader reader  = new CSVReaderBuilder(filereader).withSkipLines(0).build();
            List<String[]>Students = reader.readAll();
            for(String[] student : Students){
                ques=student[0];
                a=student[1];
                //  System.out.println(ques);
                   b=student[2];
                    c=student[3];
                     d=student[4];
                    all_questions.add(student);
          
                 
                 
            }  }
            
             else if(w==2){
            FileReader filereader = new FileReader("int.csv");
            CSVReader reader  = new CSVReaderBuilder(filereader).withSkipLines(0).build();
            List<String[]>Students = reader.readAll();
            for(String[] student : Students){
                ques=student[0];
                a=student[1];
                //  System.out.println(ques);
                   b=student[2];
                    c=student[3];
                     d=student[4];
                    all_questions.add(student);
          
                 
                 
            }  }
             
              else if(w==1){
            FileReader filereader = new FileReader("his.csv");
            CSVReader reader  = new CSVReaderBuilder(filereader).withSkipLines(0).build();
            List<String[]>Students = reader.readAll();
            for(String[] student : Students){
                ques=student[0];
                a=student[1];
                //  System.out.println(ques);
                   b=student[2];
                    c=student[3];
                     d=student[4];
                    all_questions.add(student);
          
                 
                 
            }  }
            
             else {
            FileReader filereader = new FileReader("prog.csv");
            CSVReader reader  = new CSVReaderBuilder(filereader).withSkipLines(0).build();
            List<String[]>Students = reader.readAll();
            for(String[] student : Students){
                ques=student[0];
                a=student[1];
                //  System.out.println(ques);
                   b=student[2];
                    c=student[3];
                     d=student[4];
                    all_questions.add(student);
          
                 
                 
            }  }
             
            for(int i=0;i<all_questions.size();i++){
                for(String s : all_questions.get(i)){
                    System.out.print(" " + s);
                }
                System.out.println("HAE PRint hoise");
            }
             
            // System.out.println("5");
           // Ques1 v=new Ques1();
           // v.Ques11(ques,a,b,c,d);
        }catch(Exception e){
            e.printStackTrace();
        }
  
    }
        public boolean next = false;
        public void nextClicked (boolean next){
            this.next = next;
        }
       static int w;
        public void getn(int n){
           w=n;
           
        }
 
  
     
     
}
